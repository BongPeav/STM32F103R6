/*
 * lcd4bits.h
 *
 *  Created on: Oct 18, 2023
 *      Author: Admin
 */

#ifndef INC_LCD4BITS_H_
#define INC_LCD4BITS_H_

#include "main.h"

#define DPORT GPIOC->ODR

void delay1(uint16_t dTime);
void delay2(uint8_t dTime2);
void lcdCmd(uint8_t cmd);
void lcdData(uint8_t dat);
void lcdInit(void);
void lcdStr(uint8_t *str);
void lcdXY(uint8_t x,uint8_t y);
void lcdClear(void);

#endif /* INC_LCD4BITS_H_ */
