/*
 * lcd4bits.c
 *
 *  Created on: Oct 18, 2023
 *      Author: Admin
 */

#include "lcd4bits.h"

void delay1(uint16_t dTime){
	for(uint16_t i=0;i<dTime;i++)
		for(uint8_t j=0;j<10;j++);
}

void delay2(uint8_t dTime){
	for(uint8_t i=0;i<dTime;i++) delay1(5000);
}

void lcdCmd(uint8_t cmd){
	uint8_t temp=0x02;
	DPORT=temp|(cmd&0xF0);
	delay1(10);
	temp=0;
	DPORT=temp|(cmd&0xF0);
	delay1(100);

	temp=0x02;
	DPORT=temp|(cmd<<4);
	delay1(10);
	temp=0;
	DPORT=temp|(cmd<<4);
	delay1(100);
}

void lcdDat(uint8_t dat){
	uint8_t temp=0x03;
	DPORT=temp|(dat&0xF0);
	delay1(10);
	temp=0x01;
	DPORT=temp|(dat&0xF0);
	delay1(100);

	temp=0x03;
	DPORT=temp|(dat<<4);
	delay1(10);
	temp=0x01;
	DPORT=temp|(dat<<4);
	delay1(100);
}

void lcdInit(void){
	DPORT=0x00;
	delay1(2000);
	lcdCmd(0x33);
	delay1(100);
	lcdCmd(0x32);
	delay1(100);
	lcdCmd(0x28);
	delay1(100);
	lcdCmd(0x0F);
	delay1(100);
	lcdCmd(0x01);
	delay1(1000);
	lcdCmd(0x06);
	delay1(500);
}

void lcdStr(uint8_t *str){
	while(*str) lcdDat(*str++);
}

void lcdXY(uint8_t x,uint8_t y){
	// 20x4 LCD
	uint8_t tbe[]={0x80,0xC0,0x94,0xD4};
	lcdCmd(tbe[y-1]+x-1);
	delay1(500);
}

void lcdClear(void){
	lcdCmd(0x01);
	delay1(1000);
}
